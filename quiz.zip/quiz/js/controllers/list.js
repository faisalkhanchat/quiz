
(function(){

    angular
        .module("turtleFacts")
        .controller("listCtrl", ListController);

    ListController.$inject = ['quizMetrics','DataService'];

    function ListController(quizMetrics, DataService){

        var fk = this;        
        fk.quizMetrics = quizMetrics;
        fk.data = DataService.turtlesData; 
        fk.activeTurtle = {}; 
        fk.changeActiveTurtle = changeActiveTurtle; 
        fk.activateQuiz = activateQuiz; 
        fk.search = ""; 

        function changeActiveTurtle(index){
            fk.activeTurtle = index;
        }

        function activateQuiz(){
          //  alert();
            quizMetrics.changeState(true);
        }
    }
    
   

})();
