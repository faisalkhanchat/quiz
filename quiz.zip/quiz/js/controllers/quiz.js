
(function(){

    angular
        .module("turtleFacts")
        .controller("quizCtrl", QuizController);

    QuizController.$inject = ['quizMetrics', 'DataService'];

    function QuizController(quizMetrics, DataService){
        var fk = this;
        fk.quizMetrics = quizMetrics; 
        fk.DataService = DataService; 
        
    }

})();

